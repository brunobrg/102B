# -*- coding: utf-8 -*-
"""
    teste
    ~~~~~

    Please describe your extension here...

    :copyright: (c) 2016 by gagos.
"""
